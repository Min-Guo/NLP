package HMM;


public class PathInfo {
    private String word;
    private String path;

    public void setPathInfo(String word, String path) {
        this.word = word;
        this.path = path;
    }

    public String getWord() {
        return this.word;
    }

    public String getPath() {
        return this.path;
    }

}
